import openai
import re
from neo4j import GraphDatabase

OPENAI_API_KEY = "sk-proj-SCddVD3ZWsbBhv5IScfoT3BlbkFJAJdyR6CDtI7PNCp7Uv0l"

# ---------------------------------------------
# 1. Get node labels and their properties from Neo4j
# ---------------------------------------------
def get_database_schema(driver):
    cypher_query = "CALL db.schema.nodeTypeProperties()"
    schema = {}
    with driver.session() as session:
        result = session.run(cypher_query)
        for record in result:
            label = record["nodeType"].strip("`:")
            properties = record.get("propertyNames", []) or []
            schema[label] = properties
    return schema

# ---------------------------------------------
# 2. Get relationship types from Neo4j
# ---------------------------------------------
def get_relationship_schema(driver):
    cypher_query = "MATCH ()-[r]->() RETURN DISTINCT type(r) AS relationshipType"
    relationships = set()
    with driver.session() as session:
        result = session.run(cypher_query)
        for record in result:
            relationships.add(record["relationshipType"])
    return list(relationships)

# ---------------------------------------------
# 3a. Generate Cypher query from user prompt
# ---------------------------------------------
def generate_cipher_query_from_prompt(prompt, schema, relationships):
    print("\nGPT-4 Task: Cypher query generation")

    system_prompt = "You are a Cypher query expert for a medical knowledge graph. Your job is to generate Cypher queries based on the schema provided."

    user_prompt = f"""
ONLY use the following node labels and their properties:
{schema}

ONLY use the following relationship types:
{relationships}

Instructions:
- If the user uses terms like \"cures\", \"treats\", \"used for\", or \"drugs for\", map those to the closest valid relationship.
- Use `toLower()` and `CONTAINS` to make string comparisons flexible and case-insensitive.
- Example: WHERE toLower(dis.name) CONTAINS \"stroke\"
- DO NOT invent labels, relationships, or properties.
- Ensure the generated query returns usable data such as drug names or disease names depending on the question.

Generate a Cypher query for:
{prompt}
"""

    client = openai.OpenAI(api_key=OPENAI_API_KEY)
    response = client.chat.completions.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
    )
    return response.choices[0].message.content.strip()

# ---------------------------------------------
# 3b. Generate natural language response from results
# ---------------------------------------------
def generate_response_from_kg_results(user_question, query, results):
    print("\nGPT-4 Task: Full response generation from KG data")

    system_prompt = """
You are an intelligent AI assistant working with a medical knowledge graph.

You will be given:
1. The original user question
2. The Cypher query generated to answer it
3. The results from that query

Your job is to:
- Analyze the query and its results
- Understand what the user wants
- Respond with a clear, helpful, full-sentence answer based on the results

Do not return technical or Cypher-related output. Just explain the answer naturally in English.
"""

    user_prompt = f"""
User Question:
{user_question}

Cypher Query:
{query}

Query Results:
{results}
"""

    client = openai.OpenAI(api_key=OPENAI_API_KEY)
    response = client.chat.completions.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": system_prompt.strip()},
            {"role": "user", "content": user_prompt.strip()}
        ]
    )
    return response.choices[0].message.content.strip()

# ---------------------------------------------
# 4. Extract Cypher query from GPT output
# ---------------------------------------------
def extract_cypher_code(text):
    match = re.search(r"```cypher\n(.*?)```", text, re.DOTALL | re.IGNORECASE)
    if match:
        return match.group(1).strip()
    return text.strip()

# ---------------------------------------------
# 5. Execute the Cypher query in Neo4j
# ---------------------------------------------
def execute_cypher_query(driver, cypher_query):
    print("\nExecuting Cypher query...")
    try:
        with driver.session() as session:
            result = session.run(cypher_query)
            data = [record.data() for record in result]
            print("\U0001F4CA Query Result:")
            print(data)
            return data
    except Exception as e:
        print("Error executing query:")
        print(e)
        return []

# ---------------------------------------------
# 6. Process the user prompt end-to-end
# ---------------------------------------------
def process_prompt(driver, prompt):
    schema = get_database_schema(driver)
    relationships = get_relationship_schema(driver)

    cypher_query_raw = generate_cipher_query_from_prompt(prompt, schema, relationships)
    cypher_query = extract_cypher_code(cypher_query_raw)
    print("\nGenerated Cypher Query:\n", cypher_query)

    results = execute_cypher_query(driver, cypher_query)

    if not results:
        return "No results found for your question."

    return generate_response_from_kg_results(
        user_question=prompt,
        query=cypher_query,
        results=results
    )
# ---------------------------------------------
# 7. Entry point — starts the program
# ---------------------------------------------
def main():
    print("Connecting to Neo4j...")

    neo4j_uri = "neo4j+s://d591a908.databases.neo4j.io"
    neo4j_user = "neo4j"
    neo4j_password = "jT9H3c6GL1f6ffkbNe8JpOpYoz9vxrFDhyZ60ZPZQQ0"  

    driver = GraphDatabase.driver(neo4j_uri, auth=(neo4j_user, neo4j_password))
    print("Connected!")

    try:
        user_prompt = input("\nAsk your question: ").strip()
        answer = process_prompt(driver, user_prompt)

        print("\n Final Answer:")
        print(answer)
    finally:
        driver.close()
        print("\nClosed Neo4j connection.")

# ---------------------------------------------
# 8. Run the app
# ---------------------------------------------
if __name__ == '__main__':
    main()

