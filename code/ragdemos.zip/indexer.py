import os
from langchain_openai import AzureOpenAIEmbeddings
import warnings
from dotenv import load_dotenv

load_dotenv()

warnings.filterwarnings("ignore")

CHROMA_PATH = os.path.join(os.getcwd(), "chroma_db")

# If getting upgrade warning, run the following from command line:
# chroma utils vacuum --path chroma_db
def load_document(file):
    import os
    name, extension = os.path.splitext(file)

    if extension == '.pdf':
        from langchain_community.document_loaders import PyPDFLoader
        print(f'Loading {file}')
        loader = PyPDFLoader(file)
    elif extension == '.docx':
        from langchain.document_loaders import Docx2txtLoader
        print(f'Loading {file}')
        loader = Docx2txtLoader(file)
    elif extension == '.txt':
        from langchain.document_loaders import TextLoader
        loader = TextLoader(file)
    else:
        print('Document format is not supported!')
        return None

    data = loader.load()
    return data

def chunk_data(data, chunk_size=256):
    from langchain.text_splitter import RecursiveCharacterTextSplitter
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=0)
    chunks = text_splitter.split_documents(data)
    print(len(chunks))
    return chunks 


def create_embeddings_chroma(chunks, persist_directory=CHROMA_PATH):
    from langchain_community.vectorstores import Chroma
 
    # Instantiate an embedding model from Azure OpenAI
    embeddings = AzureOpenAIEmbeddings(
        model="text-embedding-ada-002",
        api_key="",
        api_version="",
        azure_endpoint=""
    )

    # Create a Chroma vector store using the provided text chunks and embedding model, 
    # configuring it to save data to the specified directory 
    Chroma.from_documents(chunks, embeddings, persist_directory=persist_directory) 


#### MAIN PROCESSING STARTS HERE

# Load the pdf documents
documents=[]

data = load_document(os.path.join( os.getcwd(), 'ragdemo', 'hdfc_financial_statement_2024.pdf'))
documents.extend(data)

#data = load_document(os.path.join( os.getcwd(), 'ragdemo', 'pankaj_cv.pdf'))
#documents.extend(data)

print('Loaded...')
# Split the document into chunks
print('splitting documents into chunks')
chunks = chunk_data(documents, chunk_size=256)


create_embeddings_chroma(chunks)

# Create a Chroma vector store using the provided text chunks and embedding model 
print('Creating a Chroma vector store using the provided text chunks and embedding model')

print('Chroma vector db created')
