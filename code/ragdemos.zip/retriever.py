import os
from langchain_openai import AzureChatOpenAI
from langchain_openai import AzureOpenAIEmbeddings
import warnings
warnings.filterwarnings("ignore")

CHROMA_PATH = os.path.join(os.getcwd(), "chroma_db")

def load_embeddings_chroma(persist_directory=CHROMA_PATH):
    from langchain.vectorstores import Chroma

    # Instantiate the same embedding model used during creation
    print('Instantiating the embedding model')
    #model=os.getenv('AZURE_OPENAI_EMBEDDING_NAME'),
    #    api_key=os.getenv('AZURE_OPENAI_EMBEDDING_API_KEY'),
    #    api_version="2024-02-01",
    #    azure_endpoint=os.getenv('AZURE_OPENAI_EMBEDDING_ENDPOINT')
    
    embeddings = AzureOpenAIEmbeddings(
        model="",
        api_key="",
        api_version="2024-02-01",
        azure_endpoint=""
    )

    print('Loading Chroma vector database, passing the embedding model to be used to it...')
    # Load the Chroma vector store from the specified directory, using the provided embedding function
    vector_store = Chroma(persist_directory=persist_directory, embedding_function=embeddings) 

    return vector_store  # Return the loaded vector store

def ask_and_get_answer(vector_store, q, k=3):
    from langchain.chains import RetrievalQA

    #                  api_key=os.getenv('AZURE_OPENAI_API_KEY'),
    #                  api_version="2024-02-01",
    #                azure_endpoint=os.getenv('AZURE_OPENAI_ENDPOINT'),
    #                model=os.getenv('AZURE_OPENAI_MODEL_NAME')

    llm = AzureChatOpenAI(temperature=0,
                      api_key="",
                      api_version="2024-02-01",
                      azure_endpoint="",
                      model=""
            )

    print('fetching the retreiever for the vector DB')
    retriever = vector_store.as_retriever(search_type='similarity', search_kwargs={'k': k})

    print('Executing the Chain with the retriever and the LLM')
    chain = RetrievalQA.from_chain_type(llm=llm, chain_type="stuff", retriever=retriever)
    
    answer = chain.invoke(q)
    return answer
    

# Creating a Chroma vector store using the provided text chunks and embedding model (default is text-embedding-3-small)
vector_store = load_embeddings_chroma()

# Asking questions
q = 'What technical skills does Pankaj have?'
answer = ask_and_get_answer(vector_store, q)
print(answer)