import boto3
import json
import os
from dotenv import load_dotenv

load_dotenv()

bedrock_runtime = boto3.client(
    service_name='bedrock-runtime',
    region_name='us-east-1',
    aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
    aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY')
)

request_body = {
    "anthropic_version": "bedrock-2023-05-31",
    "max_tokens": 1000,
    "messages": [
        {"role": "user", "content": "Explain quantum computing briefly."}
    ]
}

response = bedrock_runtime.invoke_model_with_response_stream(
    modelId='anthropic.claude-3-sonnet-20240229-v1:0',
    body=json.dumps(request_body)
)

# Process the streaming response
for event in response.get('body'):
    chunk = json.loads(event['chunk']['bytes'])
    if 'content' in chunk and len(chunk['content']) > 0:
        print(chunk['content'][0]['text'], end='', flush=True)