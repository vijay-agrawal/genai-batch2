"""
# Twitter Data Scraping Tutorial
# -----------------------------
This notebook demonstrates how to use Twitter's API through the tweepy library to collect tweets about specific topics. The code uses both Twitter API v1.1 and v2 endpoints for authentication and data retrieval.
"""

import tweepy

"""Below are step-by-step instructions to locate your Twitter API credentials:

1. Log in to the Twitter Developer Portal:

- Visit developer.twitter.com.
- Sign in using your Twitter account. If you don’t have a developer account, follow the prompts to apply for one.
2. Access Your Developer Dashboard:

- Once logged in, click on your profile icon or “Developer Dashboard” to access your projects and apps.
3. Select or Create a Project/App:

- In the “Projects & Apps” section, you’ll see any existing projects and apps.
- If you don’t have one, click on “Create Project” and follow the instructions to set up a new project and associated app.
4. Open Your App Details:

- Click on the app for which you want to obtain credentials.
- This will open the app’s overview page with various tabs and details about your app.
5. Navigate to the Keys and Tokens Section:

- Look for a tab or section labeled “Keys and Tokens” or “Authentication Tokens.”
  Here, you will see several pieces of information, typically including:
 - API Key (Consumer Key)
 - API Key Secret (Consumer Secret)
 - Bearer Token

- For APIs that require user authentication, you may also see options to generate:
 - Access Token
 - Access Token Secret
6. Generate Additional Tokens (if necessary):

- If you need Access Tokens (for actions on behalf of your Twitter account), look for a “Generate” or “Create” button within the same section.
- Click it to generate the Access Token and Access Token Secret.
7. Copy and Secure Your Credentials:

Carefully copy all the required keys and tokens.
Store these credentials securely (for example, in a secure password manager or an environment variable file) as they are sensitive and should not be shared publicly.
Use the Credentials in Your Code:

Now that you have your API Key, API Key Secret, Bearer Token, and (if needed) Access Tokens, you can use them in your code to authenticate requests to the Twitter API.
By following these steps, you should be able to locate and use your Twitter API credentials for your projects.

Remember to keep your credentials secure to prevent unauthorized access.
"""

# Replace these with your own Twitter API credentials
api_key = "<enter consumer key>"
api_key_secret = "<enter consumer secret>"
access_token = "<enter access token>"
access_token_secret = "<enter access token secret>"

# Authenticate to Twitter using OAuth1UserHandler for v1.1 endpoints
auth = tweepy.OAuth1UserHandler(api_key, api_key_secret, access_token, access_token_secret)
# Authenticate to Twitter using Client for v2 endpoints
client = tweepy.Client(bearer_token='<Enter Bearer Token',
                      consumer_key=api_key,
                      consumer_secret=api_key_secret,
                      access_token=access_token,
                      access_token_secret=access_token_secret)


# Set up your search query
query = "apple stock -is:retweet"
max_tweets = 100

# Retrieve tweets using tweepy.Paginator for v2 API
tweets = tweepy.Paginator(client.search_recent_tweets,  # Changed to search_recent_tweets
                           query=query,
                           tweet_fields=['created_at', 'text'],  # Specify fields
                           max_results=100).flatten(limit=max_tweets)  # Limit to max_tweets

# Print tweets and store them in a list
all_tweets = []
for tweet in tweets:
    print(f"{tweet.created_at}: {tweet.text}\n")  # Changed from full_text to text
    all_tweets.append(tweet.text)  # Append tweet text

# Now you have all the tweet texts stored in the 'all_tweets' list
# You can further process or analyze this list as needed