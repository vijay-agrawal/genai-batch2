import pandas as pd
import os

# Using os.path.join() for cross-platform compatibility
file_path = os.path.join('dataingestion', 'bankloan.csv')
df = pd.read_csv(file_path)

print(df.head())

