import http.client
import pandas as pd
import json

conn = http.client.HTTPSConnection("indian-stock-exchange-api2.p.rapidapi.com")

headers = {
    'x-rapidapi-key': "3553ac1ab0msh05026b57fbbdf12p1337a8jsnd9357280419b",
    'x-rapidapi-host': "indian-stock-exchange-api2.p.rapidapi.com"
}

conn.request("GET", "/historical_data?stock_name=tcs&period=1m&filter=price", headers=headers)

res = conn.getresponse()
data = res.read()

datadict = json.loads(data.decode("utf-8"))

print(datadict['datasets'][0]['values'])


df = pd.DataFrame(datadict['datasets'][0]['values'], columns=['Date', 'Price'])

print(df.head())

df.info()
df.describe()
