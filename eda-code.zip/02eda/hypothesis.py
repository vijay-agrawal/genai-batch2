import numpy as np
from scipy.stats import chisquare

# Observed counts for each cuisine category
observed = np.array([10, 50, 20, 20])  # total is 100

# Expected distribution (25% each of 100 people):
expected = np.array([25, 25, 25, 25])

chi2_stat, p_value = chisquare(f_obs=observed, f_exp=expected)

print("Chi-square statistic:", chi2_stat)
print("p-value:", p_value)

