import pandas as pd

# Sample DataFrame
df = pd.DataFrame({
    'id': [101, 102, 103],
    'name': ['Vijay', 'Sunita', 'Megha'],
    'age': [40, 37, 33]
})

# Set 'id' as the index for fast lookups
df.set_index('id', inplace=True)

# Fast lookup using index
print(df.loc[102])  # Output: name='Sunita', age=37

# Check if a column is indexed
print(df.index)  # Shows the current index
print(df.columns)  # Shows all column names

# how to index multiple columns?
df.set_index(['id', 'name'], inplace=True)

#By default, only the row index (df.index) is optimized.
#Columns are not indexed automatically for fast searching.
#Use set_index() to explicitly create an index on a column.
#For large datasets, consider Categorical or MultiIndex for efficiency.

#now you can do fast lookups
df.loc[102]  # Fetch data for 'id' 102

df[df['name'] == 'Sunita']

#OR
df.query("name == 'Sunita'")

#For extracting only the age
df[df['name'] == 'Sunita']['age'].values[0]  # Output: 37

#Partial match
df[df['name'].str.contains('sun', case=False)]

#Fast lookup if indexed, works only for exact matches
df.loc['Sunita']

#Search multiple names
df[df['name'].isin(['Sunita', 'Megha'])]


