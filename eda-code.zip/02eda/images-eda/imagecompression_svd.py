import numpy as np
import matplotlib.pyplot as plt
from skimage import data
from skimage.color import rgb2gray

# -----------------------------
# 1. Represent the Image as a Matrix
# -----------------------------
# Load a sample image. Here we use the built-in 'camera' image which is already grayscale.
image = data.camera()  # image shape is (512, 512) for example.
print("Original image shape:", image.shape)

# (For SVD it is convenient to work in float format.)
image_float = image.astype(np.float64)

# -----------------------------
# 2. Compute the Principal Components (via SVD)
# -----------------------------
# Singular Value Decomposition (SVD) decomposes the image matrix A into U, S, V such that:
#   A = U * diag(S) * V^T
U, s, V = np.linalg.svd(image_float, full_matrices=False)
print("Shapes: U:", U.shape, "s:", s.shape, "V:", V.shape)

# -----------------------------
# 3. Project the Image onto a Smaller Set of Eigenvectors
# -----------------------------
# Choose the number of singular values (and corresponding vectors) to keep.
k = 50  # You can change k to see how it affects the reconstruction.
# Keep only the top k singular values and corresponding vectors.
U_k = U[:, :k]     # shape: (m, k)
s_k = s[:k]        # shape: (k,)
V_k = V[:k, :]     # shape: (k, n)

# -----------------------------
# 4. Reconstruct (Decompress) the Image
# -----------------------------
# Reconstruct the image using only the top k components:
#   A_approx = U_k * diag(s_k) * V_k
S_k = np.diag(s_k)
reconstructed_image = np.dot(U_k, np.dot(S_k, V_k))

# -----------------------------
# 5. Compare and Evaluate the Compression
# -----------------------------
# Display the original and the reconstructed image side by side.
fig, axes = plt.subplots(1, 2, figsize=(12, 6))

axes[0].imshow(image, cmap='gray')
axes[0].set_title("Original Image")
axes[0].axis('off')

axes[1].imshow(reconstructed_image, cmap='gray')
axes[1].set_title(f"Reconstructed Image (k = {k})")
axes[1].axis('off')

plt.tight_layout()
plt.show()

# Calculate and print the storage requirements:
# The original image has m * n values.
m, n = image.shape
original_storage = m * n

# For the compressed representation, we need to store:
#   - U_k: m * k values,
#   - s_k: k values,
#   - V_k: k * n values.
compressed_storage = (m * k) + k + (k * n)
compression_ratio = compressed_storage / original_storage

print("Original storage (number of values):", original_storage)
print("Compressed storage (approx.):", compressed_storage)
print("Compression ratio: {:.2f}".format(compression_ratio))
