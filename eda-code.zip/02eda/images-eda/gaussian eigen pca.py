import numpy as np
import matplotlib.pyplot as plt

from skimage import data, img_as_float
from skimage.filters import gaussian
from sklearn.decomposition import PCA

# 1. Load a sample image
image = img_as_float(data.astronaut())  # shape (512, 512, 3)
height, width, channels = image.shape

print("Original image shape:", image.shape, "(height, width, channels)")

# 2. Apply Gaussian blur
sigma_value = 5.0
blurred_image = gaussian(image, sigma=sigma_value, channel_axis=-1)

# 3. Flatten the image pixels to shape (num_pixels, 3)
pixels = image.reshape(-1, channels)  # Each row = [R, G, B]
print("Flattened pixels shape:", pixels.shape, "(samples, features)")
print("Data type of flattened pixels:", pixels.dtype)

# 4. PCA with fewer components (e.g., 2)
n_components = 2
pca = PCA(n_components=n_components, svd_solver='full')

# Transform to PCA space
pixels_pca = pca.fit_transform(pixels)
print("PCA-transformed shape:", pixels_pca.shape, "(samples, n_components)")

# Reconstruct from PCA space
reconstructed_pixels = pca.inverse_transform(pixels_pca)
print("Reconstructed pixel array shape:", reconstructed_pixels.shape, "(samples, features)")

# Reshape back to (height, width, channels)
pca_image = reconstructed_pixels.reshape(height, width, channels)
print("Reconstructed image shape:", pca_image.shape, "(height, width, channels)")

# 5. Plot results
fig, axes = plt.subplots(1, 3, figsize=(15, 5))

axes[0].imshow(image)
axes[0].set_title('Original')
axes[0].axis('off')

axes[1].imshow(blurred_image)
axes[1].set_title(f'Gaussian Blurred (σ={sigma_value})')
axes[1].axis('off')

axes[2].imshow(pca_image)
axes[2].set_title(f'PCA Reconstruction ({n_components} components)')
axes[2].axis('off')

plt.tight_layout()
plt.show()
