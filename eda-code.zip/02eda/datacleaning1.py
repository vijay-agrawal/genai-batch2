import pandas as pd
import numpy as np

# Download data file from Kaggle
# https://www.kaggle.com/datasets/maxhorowitz/nflplaybyplay2009to2016

# read in all our data
nfl_data = pd.read_csv("NFL Play by Play 2009-2017 (v4).csv")

# set seed for reproducibility
np.random.seed(0)

print(nfl_data.head())

print(nfl_data.info)
print (nfl_data.describe)

# get the number of missing data points per column
missing_values_count = nfl_data.isnull().sum()

# look at the # of missing points in the first ten columns
missing_values_count[0:10]

# It might be helpful to see what percentage of the values in our dataset 
# were missing to give us a better sense of the scale of this problem
# how many total missing values do we have?
total_cells = np.product(nfl_data.shape)
total_missing = missing_values_count.sum()

# percent of data that is missing
print((total_missing/total_cells) * 100 + " % values are missing")

# look at the # of missing points in the first ten columns
missing_values_count[0:10]

# drop rows with na/missing values
nfl_data.dropna()

# remove all columns with at least one missing value
columns_with_na_dropped = nfl_data.dropna(axis=1)
columns_with_na_dropped.head()

# just how much data did we lose?
print("Columns in original dataset: %d \n" % nfl_data.shape[1])
print("Columns with na's dropped: %d" % columns_with_na_dropped.shape[1])

