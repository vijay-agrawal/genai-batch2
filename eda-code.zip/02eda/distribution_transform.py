from scipy.stats import yeojohnson
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, PolynomialFeatures
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error


# **Step 1: Create Skewed Data (Log-Normal Distributed Weight)**
skewed_weights = np.random.lognormal(mean=4, sigma=0.3, size=1000)  # Log-normal distributed weights

# **Step 2: Apply Yeo-Johnson Transformation (Handles Zero & Negative Values)**
transformed_weights, lambda_val = yeojohnson(skewed_weights)

# Convert to DataFrame
skewed_data = pd.DataFrame({'Skewed Weight (kg)': skewed_weights, 'Transformed Weight (kg)': transformed_weights})

# **Step 3: Plot Original Skewed vs Transformed Data**
fig, axes = plt.subplots(1, 2, figsize=(12, 5))

# Original Skewed Weight Distribution
sns.histplot(skewed_data["Skewed Weight (kg)"], bins=30, kde=True, color='r', ax=axes[0])
axes[0].set_title("Original Skewed Weight Distribution")
axes[0].set_xlabel("Weight (kg)")
axes[0].set_ylabel("Frequency")
axes[0].grid()

# Transformed Weight Distribution (After Yeo-Johnson)
sns.histplot(skewed_data["Transformed Weight (kg)"], bins=30, kde=True, color='b', ax=axes[1])
axes[1].set_title("Transformed Weight Distribution (Normalized)")
axes[1].set_xlabel("Transformed Weight (kg)")
axes[1].set_ylabel("Frequency")
axes[1].grid()

plt.suptitle("Fixing Skewed Data Using Yeo-Johnson Transformation", fontsize=14)
plt.tight_layout()
plt.show()

# Print Lambda Value Used for Transformation
print(f"Yeo-Johnson Transformation Lambda Value: {lambda_val:.4f}")
