import numpy as np
from scipy.stats import chisquare

# Observed counts for each cuisine category
observed = np.array([30, 50, 10, 10])  # total is 100

#Assumption: There is preference for a cuisine

# Null Hypothesis:  (25% each of 100 people):
expected = np.array([25, 25, 25, 25])

chi2_stat, p_value = chisquare(f_obs=observed, f_exp=expected)

print("Chi-square statistic:", chi2_stat)
print("p-value:", p_value)
