import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

# Sample DataFrame
np.random.seed(42)
df = pd.DataFrame({
    'Feature1': np.random.normal(50, 15, 1000),
    'Feature2': np.random.exponential(10, 1000),
    'Feature3': np.random.uniform(10, 100, 1000)
})

# Plot distributions
plt.figure(figsize=(12, 6))
for i, column in enumerate(df.columns, 1):
    plt.subplot(1, len(df.columns), i)
    sns.histplot(df[column], kde=True, bins=30)  # kde=True adds a density curve
    plt.title(f'Distribution of {column}')

plt.tight_layout()
plt.show()
