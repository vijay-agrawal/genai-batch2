import matplotlib.pyplot as plt
import numpy as np
from sklearn.preprocessing import MinMaxScaler, StandardScaler, FunctionTransformer

# Example data
ages = np.array([45, 60, 52, 47, 58, 63, 50, 55]).reshape(-1, 1)
age_squared = ages**2
bp_reduction = np.array([20, 20, 20, 15, 25, 15, 25, 20]).reshape(-1, 1)

# Normalization techniques
min_max_scaler = MinMaxScaler()
standard_scaler = StandardScaler()
log_transformer = FunctionTransformer(np.log1p)  # log(x + 1) transformation

# Apply normalizations
ages_minmax = min_max_scaler.fit_transform(ages)
ages_standardized = standard_scaler.fit_transform(ages)
ages_log = log_transformer.fit_transform(ages)

age_squared_minmax = min_max_scaler.fit_transform(age_squared)
age_squared_standardized = standard_scaler.fit_transform(age_squared)
age_squared_log = log_transformer.fit_transform(age_squared)

bp_reduction_minmax = min_max_scaler.fit_transform(bp_reduction)
bp_reduction_standardized = standard_scaler.fit_transform(bp_reduction)
bp_reduction_log = log_transformer.fit_transform(bp_reduction)

# Plot: Min-Max Scaling
plt.scatter(ages_minmax, bp_reduction_minmax, color='blue', label="Min-Max Scaling")
plt.xlabel("Min-Max Scaled Age")
plt.ylabel("Min-Max Scaled BP Reduction")
plt.title("Min-Max Scaled Age vs BP Reduction")
plt.show()

plt.scatter(age_squared_minmax, bp_reduction_minmax, color='green', label="Min-Max Scaling (Age²)")
plt.xlabel("Min-Max Scaled Age²")
plt.ylabel("Min-Max Scaled BP Reduction")
plt.title("Min-Max Scaled Age² vs BP Reduction")
plt.show()

# Plot: Standardization (Z-score)
plt.scatter(ages_standardized, bp_reduction_standardized, color='red', label="Standardized Scaling")
plt.xlabel("Standardized Age")
plt.ylabel("Standardized BP Reduction")
plt.title("Standardized Age vs BP Reduction")
plt.show()

plt.scatter(age_squared_standardized, bp_reduction_standardized, color='purple', label="Standardized Scaling (Age²)")
plt.xlabel("Standardized Age²")
plt.ylabel("Standardized BP Reduction")
plt.title("Standardized Age² vs BP Reduction")
plt.show()

# Plot: Log Transformation
plt.scatter(ages_log, bp_reduction_log, color='orange', label="Log Transformation")
plt.xlabel("Log Transformed Age")
plt.ylabel("Log Transformed BP Reduction")
plt.title("Log Transformed Age vs BP Reduction")
plt.show()

plt.scatter(age_squared_log, bp_reduction_log, color='brown', label="Log Transformation (Age²)")
plt.xlabel("Log Transformed Age²")
plt.ylabel("Log Transformed BP Reduction")
plt.title("Log Transformed Age² vs BP Reduction")
plt.show()
