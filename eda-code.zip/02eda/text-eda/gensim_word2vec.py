from gensim.models import Word2Vec

# Suppose we have a list of tokenized sentences (each sentence is a list of words)
sentences = [
    ["i", "love", "nlp", "with", "gensim"],
    ["word2vec", "is", "a", "popular", "technique", "for", "embeddings"],
    ["python", "offers", "rich", "libraries", "for", "natural", "language", "processing"]
]

# Train a Word2Vec model
w2v_model = Word2Vec(sentences, vector_size=100, window=5, min_count=1, workers=2, epochs=10)

# Get the vector for a single word
word_vec = w2v_model.wv["nlp"]
print(f"Vector for 'nlp': {word_vec}")

# Find most similar words
similar_words = w2v_model.wv.most_similar("nlp", topn=3)
print("Words most similar to 'nlp':")
for word, similarity in similar_words:
    print(f"{word}: {similarity:.4f}")
