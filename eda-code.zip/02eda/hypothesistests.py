import numpy as np
import pandas as pd
from scipy import stats
import matplotlib.pyplot as plt

# -------------------------------
# Example 1: Independent t-test
# -------------------------------
# Scenario: Compare the mean blood pressure reduction (in mmHg) between two treatments.
# Treatment A: Mean reduction of 10 mmHg; Treatment B: Mean reduction of 12 mmHg.
np.random.seed(42)
n_A = 50  # number of patients in Treatment A
n_B = 50  # number of patients in Treatment B

# Simulated blood pressure reductions with some random noise
bp_reduction_A = np.random.normal(loc=10, scale=3, size=n_A)
bp_reduction_B = np.random.normal(loc=12, scale=3, size=n_B)

# Null Hypothesis: There is no statistically significant difference 
# between Treatment A and Treatment B

# Perform independent t-test
t_stat, p_value = stats.ttest_ind(bp_reduction_A, bp_reduction_B)
print("Independent t-test results:")
print("t-statistic =", t_stat)
print("p-value =", p_value)
print("Interpretation: ", 
      "A p-value < 0.05 suggests a statistically significant difference between the two treatments.\n")

# -------------------------------
# Example 2: Chi-square Test
# -------------------------------
# Scenario: Determine if there is an association between treatment type and the occurrence of side effects.
# Assume we have the following counts:
#                Side Effect: Yes   Side Effect: No
# Treatment A:           20                30
# Treatment B:           35                15
contingency_table = np.array([[20, 30],
                              [35, 15]])

chi2, p, dof, expected = stats.chi2_contingency(contingency_table)
print("Chi-square test results:")
print("Chi-square statistic =", chi2)
print("p-value =", p)
print("Degrees of freedom =", dof)
print("Expected frequencies:\n", expected)
print("Interpretation: ", 
      "A p-value < 0.05 indicates a sign ificant association between treatment type and side effects.\n")

# -------------------------------
# Example 3: One-way ANOVA
# -------------------------------
# Scenario: Compare the average recovery time (in days) across three different treatments.
np.random.seed(42)
group_A = np.random.normal(loc=7, scale=1.5, size=30)  # Treatment A
group_B = np.random.normal(loc=6.5, scale=1.5, size=30)  # Treatment B
group_C = np.random.normal(loc=8, scale=1.5, size=30)  # Treatment C

# Perform one-way ANOVA
f_stat, p_value_anova = stats.f_oneway(group_A, group_B, group_C)
print("One-way ANOVA results:")
print("F-statistic =", f_stat)
print("p-value =", p_value_anova)
print("Interpretation: ", 
      "A p-value < 0.05 suggests a significant difference in mean recovery times among the treatments.\n")

# -------------------------------
# Example 4: Pearson Correlation
# -------------------------------
# Scenario: Examine the relationship between patient age and cholesterol levels.
np.random.seed(42)
ages = np.random.randint(30, 80, 100)  # Ages between 30 and 80 years
# Simulated cholesterol levels (e.g., mg/dL) with a positive relationship to age
cholesterol = 0.5 * ages + np.random.normal(0, 10, 100)

# Calculate Pearson correlation
correlation, p_value_corr = stats.pearsonr(ages, cholesterol)
print("Pearson Correlation results:")
print("Correlation coefficient =", correlation)
print("p-value =", p_value_corr)
print("Interpretation: ", 
      "A p-value < 0.05 indicates that the correlation is statistically significant.\n")

# -------------------------------
# Visualization (Optional)
# -------------------------------
# Plotting the blood pressure reduction distributions for the two treatments (t-test example)
plt.figure(figsize=(10, 4))

plt.subplot(1, 2, 1)
plt.hist(bp_reduction_A, bins=10, alpha=0.7, label='Treatment A')
plt.hist(bp_reduction_B, bins=10, alpha=0.7, label='Treatment B')
plt.xlabel("Blood Pressure Reduction (mmHg)")
plt.ylabel("Frequency")
plt.title("Distribution of BP Reduction")
plt.legend()

# Plotting the contingency table as a heatmap for the chi-square test example
plt.subplot(1, 2, 2)
df_contingency = pd.DataFrame(contingency_table, index=['Treatment A', 'Treatment B'], columns=['Side Effect: Yes', 'Side Effect: No'])
sns.heatmap(df_contingency, annot=True, cmap='YlGnBu', fmt="d")
plt.title("Contingency Table: Treatment vs. Side Effects")

plt.tight_layout()
plt.show()
