import matplotlib.pyplot as plt
import numpy as np

# Example data
ages = np.array([45, 60, 52, 47, 58, 63, 50, 55])
age_squared = ages**2
bp_reduction = [20, 20, 20, 15, 25, 15, 25, 20]

# Plot Age vs BP Reduction
plt.scatter(ages, bp_reduction, color='blue', label="Age vs BP Reduction")
plt.xlabel("Age")
plt.ylabel("Blood Pressure Reduction (mmHg)")
plt.title("Age vs Blood Pressure Reduction (Linear)")
plt.show()

# Plot Age^2 vs BP Reduction
plt.scatter(age_squared, bp_reduction, color='green', label="Age^2 vs BP Reduction")
plt.xlabel("Age^2 (Non-linear Feature)")
plt.ylabel("Blood Pressure Reduction (mmHg)")
plt.title("Age^2 vs Blood Pressure Reduction (Non-linear)")
plt.show()
