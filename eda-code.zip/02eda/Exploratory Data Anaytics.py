import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import OneHotEncoder

# Set random seed for reproducibility
np.random.seed(42)

# Generate sample data
n_samples = 1000

# Age
age = np.random.randint(18, 70, n_samples)

# Annual Income (in lakhs, log-normally distributed)
annual_income = np.exp(np.random.normal(loc=3, scale=0.5, size=n_samples))

# City in India
cities = ['Mumbai', 'Delhi', 'Bangalore', 'Chennai', 'Kolkata', 'Hyderabad', 'Pune', 'Ahmedabad']
city = np.random.choice(cities, n_samples)

# Number of children
num_children = np.random.randint(0, 5, n_samples)

# Prior defaults (binary)
prior_defaults = np.random.choice([0, 1], n_samples, p=[0.8, 0.2])

# Late fees (skewed distribution)
late_fees = np.random.exponential(scale=1000, size=n_samples)

# Credit score (normal distribution)
credit_score = np.clip(np.random.normal(loc=700, scale=100, size=n_samples), 300, 900).astype(int)

# Loan amount (in lakhs, correlated with annual income)
loan_amount = annual_income * np.random.uniform(0.5, 2, n_samples)

# Debt to income ratio
debt_to_income = np.clip(np.random.normal(loc=0.3, scale=0.1, size=n_samples), 0, 1)

# Loan status (binary, influenced by other features)
loan_status = np.where(
    (credit_score > 700) & (debt_to_income < 0.4) & (prior_defaults == 0),
    np.random.choice([0, 1], n_samples, p=[0.9, 0.1]),
    np.random.choice([0, 1], n_samples, p=[0.6, 0.4])
)

# Create DataFrame
df = pd.DataFrame({
    'Age': age,
    'AnnualIncome': annual_income,
    'City': city,
    'NumChildren': num_children,
    'PriorDefaults': prior_defaults,
    'LateFees': late_fees,
    'CreditScore': credit_score,
    'LoanAmount': loan_amount,
    'DebtToIncomeRatio': debt_to_income,
    'LoanStatus': loan_status
})

# Display first few rows and basic information
print(df.head())
print(df.info())

# Basic statistics
print(df.describe())

# Correlation matrix (only for numeric columns)
numeric_columns = df.select_dtypes(include=[np.number]).columns
correlation_matrix = df[numeric_columns].corr()
plt.figure(figsize=(12, 10))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm')
plt.title('Correlation Matrix')
plt.show()

# Bivariate analysis: LoanStatus vs CreditScore
plt.figure(figsize=(10, 6))
sns.boxplot(x='LoanStatus', y='CreditScore', data=df)
plt.title('Loan Status vs Credit Score')
plt.show()

# Log transformation of AnnualIncome
df['LogAnnualIncome'] = np.log(df['AnnualIncome'])

# Compare distributions
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 5))
sns.histplot(df['AnnualIncome'], kde=True, ax=ax1)
ax1.set_title('Annual Income Distribution')
sns.histplot(df['LogAnnualIncome'], kde=True, ax=ax2)
ax2.set_title('Log-transformed Annual Income Distribution')
plt.show()

# Binning Age
df['AgeBin'] = pd.cut(df['Age'], bins=[0, 30, 40, 50, 60, 100], labels=['18-30', '31-40', '41-50', '51-60', '60+'])

# One-hot encoding for City
try:
    # For newer versions of scikit-learn
    encoder = OneHotEncoder(sparse=False)
except TypeError:
    # For older versions of scikit-learn
    encoder = OneHotEncoder()

city_encoded = encoder.fit_transform(df[['City']])
if isinstance(city_encoded, np.ndarray):
    city_encoded_df = pd.DataFrame(city_encoded, columns=encoder.get_feature_names_out(['City']))
else:
    city_encoded_df = pd.DataFrame(city_encoded.toarray(), columns=encoder.get_feature_names_out(['City']))

df = pd.concat([df, city_encoded_df], axis=1)

# Analyze loan approval rate by age group
loan_approval_by_age = df.groupby('AgeBin')['LoanStatus'].mean().sort_values(ascending=False)
plt.figure(figsize=(10, 6))
loan_approval_by_age.plot(kind='bar')
plt.title('Loan Approval Rate by Age Group')
plt.ylabel('Approval Rate')
plt.show()

# Analyze loan amount distribution by city
plt.figure(figsize=(12, 6))
sns.boxplot(x='City', y='LoanAmount', data=df)
plt.title('Loan Amount Distribution by City')
plt.xticks(rotation=45)
plt.show()

# Relationship between Debt-to-Income Ratio and Loan Status
plt.figure(figsize=(10, 6))
sns.scatterplot(x='DebtToIncomeRatio', y='CreditScore', hue='LoanStatus', data=df)
plt.title('Debt-to-Income Ratio vs Credit Score, colored by Loan Status')
plt.show()

print("EDA completed. You can further analyze the data based on specific questions or hypotheses.")